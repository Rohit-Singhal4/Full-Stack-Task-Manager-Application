/** @type {import('tailwindcss').Config} */

const defaultTheme = require('tailwindcss/defaultTheme')

module.exports = {
  content: [
    "./src/**/*.{html,ts}",
  ],
  theme: {
    fontFamily: {
      sans: ['"PT Sans"', 'sans-serif']
    },
    fontSize: {
      sm: '0.8rem',
      base: '1rem',
      xl: '1.25rem',
      '2xl': '2.563rem',
      '3xl': '3.953rem',
      '4xl': '4.441rem',
      '5xl': '5.052rem',
      '6xl': '6.052rem',
      '7xl': '7.052rem',
      '8xl': '14.052rem',
      '9xl': '28.052rem',
    }
  },
  plugins: [],
}

