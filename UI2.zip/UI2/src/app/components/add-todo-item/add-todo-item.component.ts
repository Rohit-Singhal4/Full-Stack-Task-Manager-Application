import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { GroupsService } from '../../api/groups.service';
import { TodoItemsService } from '../../api/todoItems.service';
import { CreateTodoItemRequest } from '../../model/createTodoItemRequest';
import { Group } from '../../model/group';
import { Priority } from '../../model/priority';

@Component({
  selector: 'app-add-todo-item',
  standalone: true,
  imports: [
    RouterLink,
    ReactiveFormsModule,
    CommonModule
  ],
  template: `
    <div class="bg-stone-200 min-h-screen flex items-center justify-center">
      <div class="p-10 w-1/2 h-3/4 text-black my-10">
        <p class="text-2xl font-bold mb-6 text-center underline mt-8">Add New Task</p>
        <form [formGroup]="todoForm" (ngSubmit)="onSaveClick()" class="space-y-4">
          <div class="mt-12">
            <label for="name" class="text-sm lg:text-2xl font-medium mr-4 mt-8">Name:</label>
            <input type="text" id="name" formControlName="name" class="input-field lg:text-2xl bg-stone-100 p-1 border-b-2 border-black text-orange-600">
          </div>
          <div class="mt-12">
            <label for="priority" class="text-sm lg:text-2xl font-medium mr-4">Priority:</label>
            <select id="priority" formControlName="priority" class="input-field lg:text-2xl bg-stone-100 p-1 border-b-2 border-black text-orange-600">
              @for(priority of priorities; track priority){
                <option [value]="priority">{{ priority }}</option>
              }
              @empty{
                <p>No priorities found</p>
              }
            </select>
          </div>
          <div class="mt-12">
            <label for="dueDate" class="text-sm lg:text-2xl font-medium mr-4">Due Date:</label>
            <input type="date" id="dueDate" formControlName="dueDate" class="input-field text-2xl bg-stone-100 p-4 border-b-2 border-black text-orange-600">
          </div>
          <div class="mt-12">
            <label for="description" class="block text-sm lg:text-2xl font-medium mt-12">Description:</label>
            <textarea id="description" formControlName="description" rows="3" class="input-field mt-6 lg:text-xl bg-stone-100 w-full p-1 border-b-2 border-black text-orange-600"></textarea>
          </div>
          <div class="mt-12">
            <label for="groupId" class="text-2xl font-medium mb-1 mr-4">Group:</label>
            <select id="groupId" formControlName="groupId" class="input-field lg:text-2xl bg-stone-100 text-black p-1 border-b-2 border-black text-orange-600">
              @for(group of groupsList; track group.id){
                <option [value]="group.id">{{ group.name }}</option>
              }
              @empty{
                <p>No group found</p>
              }
            </select>
          </div>
          <div class="flex justify-end">
            <button type="button" (click)="onCancelClick()" class="bg-gray-300 text-black py-5 px-4 hover:bg-red-600 focus:outline-none focus:bg-red-600 mr-4 border-b-2 border-black lg:text-xl">Cancel</button>
            <button type="submit" class="bg-green-500 text-black py-5 px-4 hover:bg-green-600 focus:outline-none focus:bg-green-600 border-b-2 border-black lg:text-xl">Save Task</button>
          </div>
        </form>
      </div>
    </div>

  `,
  styles: ``
})
export class AddTodoItemComponent {

  groupId: number = -1;
  todoForm!: FormGroup;
  priorities: string[] = [];
  groupsList: Group[] = [];

  todoItemsService: TodoItemsService = inject(TodoItemsService);
  groupsService: GroupsService = inject(GroupsService);
  router: Router = inject(Router);
  formBuilder: FormBuilder = inject(FormBuilder);
  route: ActivatedRoute = inject(ActivatedRoute);

  ngOnInit(): void {
    this.todoForm = this.formBuilder.group({
      name: ['', Validators.required],
      priority: ['', Validators.required],
      dueDate: [null, Validators.required],
      description: ['', Validators.required],
      groupId: [null, Validators.required]
    });

    this.groupsService.getAllGroups().subscribe(groups => {
      this.groupsList = groups;
    });

    this.priorities = Object.values(Priority) as string[];

    this.route.paramMap.subscribe(params => {
      this.groupId = Number(params.get('groupId'));
      this.todoForm.patchValue({ groupId: this.groupId });
    });

    console.log('Group ID:', this.groupId);
  }

  onCancelClick(): void {
    if(this.groupId){
      this.router.navigate(['/'], { queryParams: { group: this.groupId } });
    }
    else{
      this.router.navigate(['/']);
    }
  }

  onSaveClick(): void {
      const dueDateValue = this.todoForm.value.dueDate;
      const formattedDueDate =
        typeof dueDateValue === 'string'
          ? new Date(dueDateValue)
          : dueDateValue;

      const newTodoItem: CreateTodoItemRequest = {
        name: this.todoForm.value.name,
        priority: this.todoForm.value.priority,
        dueDate: formattedDueDate,
        description: this.todoForm.value.description,
        groupId: this.todoForm.value.groupId
      };

      this.todoItemsService.createTodoItem(newTodoItem).subscribe(() => {
        this.router.navigate(['/'], { queryParams: { group: this.todoForm.value.groupId } });
      });
  }

}
