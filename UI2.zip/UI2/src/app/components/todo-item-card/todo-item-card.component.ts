import { CommonModule } from '@angular/common';
import { Component, inject, input, output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialog } from '@angular/material/dialog';
import { RouterLink } from '@angular/router';
import { catchError, filter, switchMap, tap, throwError } from 'rxjs';
import { TodoItemsService } from '../../api/todoItems.service';
import { DeleteTodoItemResponse } from '../../model/deleteTodoItemResponse';
import { PatchTodoItemRequest } from '../../model/patchTodoItemRequest';
import { TodoItem } from '../../model/todoItem';
import { TodoItemResponse } from '../../model/todoItemResponse';
import { DeleteTodoItemComponent } from '../delete-todo-item/delete-todo-item.component';

@Component({
  selector: 'app-todo-item-card',
  standalone: true,
  imports: [
    MatCheckboxModule,
    FormsModule,
    RouterLink,
    CommonModule
  ],
  template: `
    <div class="task-content bg-orange-500 p-8 shadow-lg text-white transform hover:-translate-y-2 hover:shadow-2xl transition-transform duration-300 border-2 border-black border-dashed" 
    [class.completed]="todoItem().isComplete">
      <div class="flex flex-col h-full">
        <div class="flex items-center space-x-3 mb-4">
          <mat-checkbox color="primary" [checked]="todoItem().isComplete"
            (change)="onCheckboxChange($event)"
                            class="rounded-full mb-3">
          </mat-checkbox>
          <p class="task-content text-lg font-semibold task-content truncate flex-grow" [class.completed]="todoItem().isComplete">{{ todoItem().name }}</p>
          <a [routerLink]="'editTodoItem/' + todoItem().id" class="task-content text-white hover:text-black mb-3" [class.completed]="todoItem().isComplete">
            <i class="fas fa-edit"></i>
          </a>
          <button (click)="onDeleteClick()" class="task-content text-white hover:text-black mb-3" [class.completed]="todoItem().isComplete">
            <i class="fas fa-trash"></i>
          </button>
        </div>
        <div class="mb-4">
          <p class="task-content" [class.completed]="todoItem().isComplete"><span class="font-semibold">Description:</span> {{ todoItem().description }}</p>
        </div>
        <div class="text-sm">
          <p class="task-content" [class.completed]="todoItem().isComplete"><span class="font-semibold">Priority:</span> {{ todoItem().priority }}</p>
          <p class="task-content" [class.completed]="todoItem().isComplete"><span class="font-semibold">Due Date:</span> {{ todoItem().dueDate }}</p>
        </div>
      </div>
    </div>
  `,
  styles: 
  `
    .task-content.completed {
      text-decoration: line-through;
      color: #3b3b3b;
      background-color: #cfcfcf;
    }
  `
})
export class TodoItemCardComponent {

  todoItem = input.required<TodoItem>();
  todoItemChanged = output<number | undefined>();

  todoItemsService: TodoItemsService = inject(TodoItemsService);
  dialog: MatDialog = inject(MatDialog);

  onCheckboxChange(event: any | undefined) {
    if (this.todoItem()) {
      this.todoItem().isComplete = event.checked;
      const patchBody: PatchTodoItemRequest = {
        isComplete: this.todoItem().isComplete,
      };

      const id = this.todoItem()?.id;
      console.log('Changing TodoItem:', this.todoItem().id);

      this.todoItemsService.patchTodoItem(patchBody, id!)
        .pipe(
          tap((response: TodoItemResponse) => {
            console.log('TodoItem changed successfully:', response);
            this.todoItemChanged.emit(response.id);
          }),
          catchError((error: any) => {
            console.error('Error changing TodoItem:', error);
            this.todoItem().isComplete = !this.todoItem()?.isComplete;
            return throwError(() => new Error(error))
          })
        ).subscribe();
    } else {
      console.error('Todo item or its ID is undefined.');
    }
  }


  onDeleteClick() {
    const dialogRef = this.dialog.open(DeleteTodoItemComponent, {
      width: '400px',
      data: this.todoItem(),
    });
  
    dialogRef.afterClosed()
      .pipe(
        filter(result => !!result),
        switchMap((confirmedId: number) =>
          this.todoItemsService.deleteTodoItem({ id: confirmedId })
            .pipe(
              tap((response: DeleteTodoItemResponse) => {
                console.log('TodoItem deleted successfully:', response);
                this.todoItemChanged.emit(confirmedId);
              }),
              catchError(error => {
                console.error('Error deleting TodoItem:', error);
                return throwError(() => new Error(error));
              })
            )
        )
      )
      .subscribe();


  }

}