import { CommonModule } from '@angular/common';
import { Component, SimpleChanges, input, output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { catchError, tap, throwError } from 'rxjs';
import { GroupsService } from '../../api/groups.service';
import { Group, GroupResponse, TodoItem, UpdateGroupRequest } from '../../model/models';
import { EditGroupComponent } from '../edit-group/edit-group.component';

@Component({
  selector: 'app-group-stats',
  standalone: true,
  imports: [
    CommonModule,
    MatIconModule
  ],
  template: `
      <div class="flex text-black">
        <div class="w-1/3 bg-orange-500 rounded-md my-4 mx-4 border border-2 border-dashed border-gray-700"></div>
        <div class="w-full flex flex-col columns-2 gap-4 justify-center items-center">
          <div class="p-4 flex justify-between w-full">
            <div class="h-full">
              <h2 class="text-2xl font-extrabold mb-4 left-0 top-0">GROUP STATS</h2>
              <div class="mb-2 bottom-0 left-0">
                <span>TOTAL TODO ITEMS: </span>
                <span class="font-semibold">{{ totalTodoItems }}</span>
              </div>
              <div class="mb-2">
                <span>COMPLETE: </span>
                <span class="font-semibold">{{ completedTodoItems }}</span>
              </div>
              <div class="mb-2">
                <span>INCOMPLETE: </span>
                <span class="font-semibold">{{ incompleteTodoItems }}</span>
              </div>
              <div class="mb-2">
                  <span>DUE SOON (NEXT 7 DAYS): </span>
                  <span class="font-semibold">{{ dueSoon }}</span>
              </div>
          </div>
            <div>
              <p class="font-semibold mt-8 underline">PRIORITIES:</p>
              <div *ngFor="let priorityCount of priorities" class="mb-1">
                <span>{{ priorityCount.priority.toUpperCase() }}: </span>
                <span class="font-semibold">{{ priorityCount.count }}</span>
              </div>
              <div class="justify-end">
                <button mat-icon-button color="primary" (click)="onEditClick()" class="mt-4">
                  <mat-icon>edit</mat-icon>
                </button>
              </div>
            </div>
        </div>
        </div>
        <div class="w-1/3 bg-orange-500 rounded-md my-4 mx-4 border border-2 border-dashed border-gray-700">
        </div>
      </div>
  `,
})

export class GroupStatsComponent {

  group = input.required<Group | undefined>();
  todoItemsList = input.required<TodoItem[]>();
  groupEdited = output();

  totalTodoItems: number = 0;
  completedTodoItems: number = 0;
  incompleteTodoItems: number = 0;
  priorities: { priority: string, count: number }[] = [];
  dueSoon: number = 0;

  constructor(
    public dialog: MatDialog,
    private groupsService: GroupsService
  ) {}

  ngOnInit() {
    this.loadGroupStats();
  }

  ngOnChanges(changes: SimpleChanges) {
    this.loadGroupStats();
  }

  loadGroupStats() {
    this.totalTodoItems = this.todoItemsList().length;
    this.completedTodoItems = this.todoItemsList()!.filter(todo => todo.isComplete).length;
    this.incompleteTodoItems = this.totalTodoItems - this.completedTodoItems;

    const priorityCounts: { [priority: string]: number } = {};
    this.todoItemsList()!.forEach(todo => {
      if (todo.priority) {
        priorityCounts[todo.priority] = (priorityCounts[todo.priority] || 0) + 1;
      }
    });
    this.priorities = Object.keys(priorityCounts).map(priority => ({ priority, count: priorityCounts[priority] }));

    this.dueSoon = this.todoItemsList()!.filter(todo => this.isDueSoon(todo.dueDate ? new Date(todo.dueDate) : undefined)).length;
  }

  isDueSoon(dueDate: Date | undefined): boolean {
    if (!dueDate) {
      return false;
    }
    const today = new Date();
    const nextWeek = new Date();
    nextWeek.setDate(today.getDate() + 7);
    return dueDate.getTime() <= nextWeek.getTime();
  }

  getUppercase(object: string): string {
    return object.replace(/[^a-zA-Z]/g, "").toUpperCase() || '';
  }

  onEditClick() {
    const dialogRef = this.dialog.open(EditGroupComponent, {
      width: '400px',
      data: this.group()
    });

    dialogRef.afterClosed().subscribe((result: Group) => {
      if (result && result.id !== undefined) {
        const updateBody: UpdateGroupRequest = {
          name: result.name
        };
        
        this.groupsService.updateGroup(updateBody, result.id)
          .pipe(
            tap((response: GroupResponse) => {
              console.log('Group updated successfully:', response);
              this.groupEdited.emit();
            }),
            catchError((error: any) => {
              console.error('Error updating group:', error);
              return throwError(() => new Error(error))
            })
          ).subscribe();
      }
    });
  }

}
