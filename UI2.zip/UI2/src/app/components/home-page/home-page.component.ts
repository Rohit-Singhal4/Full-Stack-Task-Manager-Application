import { animate, state, style, transition, trigger } from '@angular/animations';
import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog } from '@angular/material/dialog';
import { MatIcon } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { ActivatedRoute, Router } from '@angular/router';
import { GroupsService } from '../../api/groups.service';
import { Group } from '../../model/group';
import { SortOrder } from '../../model/models';
import { GroupContainerComponent } from '../group-container/group-container.component';
import { HomeHeaderComponent } from '../home-header/home-header.component';

@Component({
  selector: 'app-home-page',
  standalone: true,
  imports: [
    HomeHeaderComponent,
    GroupContainerComponent,
    CommonModule,
    MatIcon,
    MatMenuModule,
    MatButtonModule
  ],
  template: `
    <div class="h-full bg-stone-200 justify-center">

        <app-home-header class="fixed top-0 w-full z-50 bg-stone-200"
          [groupsList]="groupsList"
          (groupChange)="getGroups()"
          [(selectedGroup)]="selectedGroup"
          (completionFilterChanged)="onCompletionFilterChanged($event!)"
          (sortOrderChanged)="onSortOrderChanged($event)">
        </app-home-header>

      <div class="w-full h-full"> 
        @if(selectedGroup?.id){
          <div [@fadeIn]>
            <app-group-container 
                [group]="selectedGroup"
                [selectedSortOrder]="selectedSortOrder" 
                [selectedCompletion]="selectedCompletion"
                (groupChanged)="onGroupChange($event)">
            </app-group-container>
        </div>
        }
        @else {
          <p></p>
        }
      </div>
    </div>
  `,
  styles: ``,
  animations: [
    trigger('fadeIn', [
      state('void', style({ opacity: 0 })),
      transition('void => *', [animate('0.3s ease-in')]),
    ]),
  ],
})
export class HomePageComponent {

  selectedGroup: Group | undefined = {};
  groupsList: Group[] = [];
  selectedSortOrder: SortOrder | undefined = undefined;
  selectedCompletion: boolean | undefined = false;
  groupIdParam: number= -1;

  groupsService: GroupsService = inject(GroupsService);
  dialog: MatDialog = inject(MatDialog);
  route: ActivatedRoute = inject(ActivatedRoute);
  router: Router = inject(Router);


  ngOnInit() {
    this.getGroups();
  }

  getGroups() {
    this.groupsService.getAllGroups().subscribe({next: value => {
      this.groupsList = value;
      this.selectedGroup = this.groupsList.find(group => group.id === this.groupIdParam);

      this.route.queryParams.subscribe(params => {
        if(params['group']){
          console.log('Group ID:', params['group']);
          this.groupIdParam = parseInt(params['group']);
          this.selectedGroup = this.groupsList.find(group => group.id === parseInt(params['group']));
        }
      });
    }});
  }

  onChangeSelectedGroup(event: number | null) {
    if(event === null) {
      this.selectedGroup = {};
      return;
    }else{
      //this.groupService.getGroup(event).subscribe({next: value => this.selectedGroup = value});
      this.selectedGroup = this.groupsList.find(group => group.id === event);
      console.log('Selected Group in onChangeSelectedGroup:', this.selectedGroup);
    }
  }

  onGroupChange(event: number) {
    this.getGroups();
    this.selectedGroup = this.groupsList.find(group => group.id === event);
    this.router.navigate(['/'], { queryParams: { group: this.selectedGroup?.id } });
  }

  onCompletionFilterChanged(filter: boolean | undefined) {
    this.selectedCompletion = filter;
  }

  onSortOrderChanged(order: SortOrder | undefined) {
    this.selectedSortOrder = order;
  }
  
}

