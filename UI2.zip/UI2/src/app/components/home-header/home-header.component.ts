import { animate, state, style, transition, trigger } from '@angular/animations';
import { CommonModule } from '@angular/common';
import { Component, inject, input, model, output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog } from '@angular/material/dialog';
import { MatIcon } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import gsap from 'gsap';
import SplitType from 'split-type';
import { GroupsService } from '../../api/groups.service';
import { CreateGroupRequest, DeleteGroupResponse, DeleteRequest, Group, SortOrder } from '../../model/models';
import { AddGroupComponent } from '../add-group/add-group.component';
import { DeleteGroupComponent } from '../delete-group/delete-group.component';


@Component({
  selector: 'app-home-header',
  standalone: true,
  imports: [
    MatMenuModule,
    MatButtonModule,
    FormsModule,
    CommonModule,
    MatIcon
  ],
  template: `
    <div class="bg-stone-200 text-black flex flex-col lg:flex-row items-center justify-between p-6">
      <!-- Column 1: Title -->
      <div class="w-full lg:w-1/4 h-auto lg:h-full flex flex-col lg:flex-row items-center justify-start p-6 lg:p-12">
          <a href="#top" id="title" class="text-2xl lg:text-4xl font-bold flex-grow" [@fadeIn]>
              todoApp/ui/.
          </a>
      </div>
      <!-- Column 2: Empty Space -->
      <div class="lg:block lg:w-1/4 h-auto lg:h-full"></div>
      <!-- Column 3: Sort and Completion -->
      <div class="w-full lg:w-1/4 h-auto lg:h-full flex flex-col lg:flex-row items-center justify-center p-4 lg:p-12 text-3xl">
        @if(selectedGroup() !== undefined && selectedGroup() !== null){
          <div class="w-full lg:w-1/2 h-auto lg:h-full flex-col text-right relative z-10">
            <div class="flex justify-end text-2xl lg:text-4xl p-2 cursor-pointer transition-transform duration-300 transform hover:translate-x-1 hover:underline hover:text-yellow-600" 
              (mouseenter)="toggleSortOrderDropdown()" [@fadeIn]>
                  <p>sort.</p>
                  @if(this.selectedSortOrder){
                  <p class="text-orange-600">
                      {{ this.selectedSortOrder }}
                  </p>  
                  }
                  @else {
                  <p class="text-4xl">ORDER</p>
                  }
            </div>
            <div class="absolute bg-black text-white text-right p-2 right-0 z-20 transition-opacity duration-300 opacity-0"
                (mouseenter)="sortOrderDropdownOpen = true" 
                (mouseleave)="sortOrderDropdownOpen = false"
                [ngClass]="{'opacity-100': sortOrderDropdownOpen, 'opacity-0': !sortOrderDropdownOpen}">
                @if(sortOrderDropdownOpen && selectedGroup()){
                  <p class="p-8 hover:underline text-3xl lg:text-4xl" (click)="sortOrder({ value: undefined, label: undefined })">
                    None
                  </p>
                  @for(option of sortOrderOptions; track option){
                    <p class="p-8 hover:underline text-3xl lg:text-4xl" (click)="sortOrder(option)">
                      {{ option.label }}
                    </p>
                  }
                  @empty {
                    <p class="text-2xl lg:text-4xl">No sort options</p>
                  }
                }
              </div>
              <div class="flex justify-end text-2xl lg:text-4xl p-2 cursor-pointer transition-transform duration-300 transform hover:translate-x-1 hover:underline hover:text-yellow-600 mt-6 lg:mt-10"
                (mouseenter)="toggleCompletionDropdown()" [@fadeIn]>
                  <p>completion.</p>
                  @if(selectedCompletion){
                    <p class="text-orange-600">{{ this.selectedCompletion }}</p>
                  }
                  @else {
                    <p>FILTER</p>
                  }
              </div>
              <div class="absolute bg-black text-white text-right p-2 right-0 z-20 transition-opacity duration-300 opacity-0" 
                (mouseenter)="completionDropdownOpen = true" 
                (mouseleave)="completionDropdownOpen = false"
                [ngClass]="{'opacity-100': completionDropdownOpen, 'opacity-0': !completionDropdownOpen}">
                  @if(completionDropdownOpen && selectedGroup()){
                    @for(option of completionOptions; track option){
                      <p class="p-8 hover:underline text-2xl lg:text-4xl" (click)="sortCompletion(option)">
                        {{ option.label }}
                      </p>
                   }
                    @empty {
                    <p class="text-2xl lg:text-4xl">No completion options</p>
                    }
                  }
              </div>
            </div>
          }
          @else if(!this.selectedGroup()){
            <div class="w-full lg:w-1/2 h-auto lg:h-full flex-col text-right relative z-10">
              <p id="sort" class="text-2xl lg:text-4xl cursor-pointer transition-transform duration-300 transform hover:translate-x-1 hover:underline hover:text-yellow-600"></p>
              <p id="complete" class="text-2xl lg:text-4xl cursor-pointer transition-transform duration-300 transform hover:translate-x-1 hover:underline hover:text-yellow-600"></p>
            </div>
          }
      </div>
      <!-- Column 4: Group -->
      <div class="w-full lg:w-1/4 h-auto lg:h-full flex flex-col lg:flex-row items-center justify-end p-6 lg:p-12 relative">  
        <div class="flex justify-end text-2xl lg:text-4xl transition-transform duration-300 transform hover:translate-x-1 hover:text-yellow-600" 
          (mouseenter)="toggleGroupDropdown()" [@fadeIn]>
          <p class="underline decoration-black hover:decoration-yellow-600">GROUP.</p>
          @if(this.selectedGroup()){
              <p class="text-orange-600 underline decoration-orange-600">{{ getUppercase(this.selectedGroup()?.name) }}</p>
          }
          @else {
              <p class="underline hover:text-yellow-400">NAME</p>
          }
        </div>
        <!-- Group Dropdown -->
        <div class="absolute right-0 top-0 mt-10 bg-black text-white text-right justify-end p-2 z-20 transition-opacity duration-300 opacity-0 max-h-96 overflow-y-auto" 
            [ngClass]="{'opacity-100': groupDropdownOpen, 'opacity-0': !groupDropdownOpen}"
            (mouseenter)="groupDropdownOpen = true" 
            (mouseleave)="groupDropdownOpen = false">
            @if(groupDropdownOpen){
                @for(group of groupsList(); track group){
                    <div class="flex items-center text-left">
                        <p class="p-8 hover:underline hover:text-yellow-400 text-2xl lg:text-4xl" (click)="selectGroup(group)">
                            {{ group.name }}
                        </p>
                        <button class="text-white text-2xl lg:text-4xl justify-end hover:text-red-700 " 
                            (click)="onDeleteGroupClick(group)">
                            <mat-icon class="">close</mat-icon>
                        </button>
                    </div>
                }
                @empty {
                    <p class="text-2xl lg:text-4xl">No groups</p>
                }
                <button class="text-white text-4xl lg:text-4xl hover:text-green-500" 
                    (click)="onAddGroupClick()">
                        <mat-icon>add</mat-icon>
                </button>
            }
        </div>
      </div>
    </div>
  `,
  styles: `
    .animate{
      clip-path: polygon(0 0, 100% 0, 100% 100%, 0% 100%);
    }
  `,
  animations: [
    trigger('fadeIn', [
        state('void', style({ opacity: 0 })),
        transition('void => *', [
            animate('1.0s', style({ opacity: 0 })),
            animate('0.75s ease-in')
        ]),
    ]),
  ],
})
export class HomeHeaderComponent {

  groupsList = input.required<Group[]>();
  selectedGroup = model.required<Group | undefined>({});
  groupChange = output();
  completionFilterChanged = output<boolean | undefined>();
  sortOrderChanged = output<SortOrder | undefined>();

  sortOrderDropdownOpen: boolean = false;
  completionDropdownOpen: boolean = false;
  groupDropdownOpen: boolean = false;
  showFilterDropdowns: boolean = false;
  selectedSortOrder: string | undefined = undefined;
  selectedCompletion: string | undefined = undefined;

  sortOrderOptions = [
    { label: 'ascending.DUEDATE', value: SortOrder.DueDateAsc },
    { label: 'descending.DUEDATE', value: SortOrder.DueDateDesc },
    { label: 'ascending.PRIORITY', value: SortOrder.PriorityAsc },
    { label: 'descending.PRIORITY', value: SortOrder.PriorityDesc },
  ];

  completionOptions = [
    { label: 'ALL', value: undefined },
    { label: 'COMPLETE', value: true },
    { label: 'INCOMPLETE', value: false },
  ];

  groupsService: GroupsService = inject(GroupsService);
  dialog: MatDialog = inject(MatDialog);

  ngOnInit() {
    this.completionFilterChanged.emit(undefined);
  }

  ngAfterViewInit(): void {
    let title = new SplitType('#title');
    let characters = document.querySelectorAll('.char');
    for (let i = 0; i < characters.length; i++) {
      characters[i].classList.add('translate-y-full');
    }

    gsap.to('.char', {
      y: 0,
      stagger: 0.05,
      delay: 0.02,
      duration: 0.5,
    });
  }

  onAddGroupClick() {
    const dialogRef = this.dialog.open(AddGroupComponent, {
      width: '400px',
    });
  
    dialogRef.afterClosed().subscribe((result: CreateGroupRequest) => {
      if (result) {
        this.groupsService.createGroup(result).subscribe(
          () => {
            console.log('Group added successfully');
            this.groupChange.emit();
          },
          error => {
            console.error('Error creating group:', error);
          }
        );
      }
    });
  }

  onDeleteGroupClick(group: Group) {
    console.log('Deleting group:', group);
    const dialogRef = this.dialog.open(DeleteGroupComponent, {
      width: '400px',
      data: group
    });
  
    dialogRef.afterClosed().subscribe((result: number | undefined) => {
      if (result !== undefined) {
        console.log('Deleting group result:', result);
        const deleteBody: DeleteRequest = { id: result };
        this.groupsService.deleteGroup(deleteBody).subscribe(
          (response: DeleteGroupResponse) => {
            console.log('Group deleted successfully:', response);
            this.groupChange.emit();
          },
          (error: any) => {
            console.error('Error deleting group:', error);
          }
        );
      }
    });
  }

  toggleSortOrderDropdown() {
    this.sortOrderDropdownOpen = !this.sortOrderDropdownOpen;
    this.completionDropdownOpen = false;
    this.groupDropdownOpen = false;
  }

  sortOrder(option: { value: SortOrder | undefined; label: string | undefined; }) {
    this.sortOrderChanged.emit(option.value);
    this.sortOrderDropdownOpen = false;
    this.selectedSortOrder = option.label;
  }

  toggleCompletionDropdown() {
    this.completionDropdownOpen = !this.completionDropdownOpen;
    this.sortOrderDropdownOpen = false;
    this.groupDropdownOpen = false;
  }

  sortCompletion(option: { value: boolean | undefined; label: string | undefined; }) {
    this.completionFilterChanged.emit(option.value);
    this.completionDropdownOpen = false;
    this.selectedCompletion = option.label;
  }

  toggleGroupDropdown() {
    this.groupDropdownOpen = !this.groupDropdownOpen;
    this.sortOrderDropdownOpen = false;
    this.completionDropdownOpen = false;
  }

  selectGroup(option: Group) {
    this.selectedGroup.set(option);
    this.showFilterDropdowns = true;
    this.groupDropdownOpen = false;
  }

  getUppercase(name: string | undefined): string {
    return name?.replace(/[^a-zA-Z]/g, "").toUpperCase() || '';
  }

}