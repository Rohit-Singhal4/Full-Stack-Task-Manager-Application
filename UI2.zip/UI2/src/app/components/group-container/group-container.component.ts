import { animate, state, style, transition, trigger } from '@angular/animations';
import { CommonModule } from '@angular/common';
import { Component, ElementRef, OnInit, SimpleChanges, ViewChild, inject, input, output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { RouterLink } from '@angular/router';
import { TodoItemsService } from '../../api/todoItems.service';
import { Group, Priority, SortOrder, TodoItem } from '../../model/models';
import { GroupStatsComponent } from '../group-stats/group-stats.component';
import { TodoItemCardComponent } from '../todo-item-card/todo-item-card.component';
import { gsap } from 'gsap';


@Component({
  selector: 'app-group-container',
  standalone: true,
  imports: [
    TodoItemCardComponent,
    GroupStatsComponent,
    FormsModule,
    MatIconModule,
    MatButtonModule,
    CommonModule,
    RouterLink
  ],
  template: `
    <div class="bg-stone-200 text-black h-screen">
      <div class="spacer h-3/6"></div>
      <div class="h-1/6 flex items-center justify-center relative" #groupWrapper>
        @for(text of repeatedTexts; track text){
          @if(group()){
            <p class="text-9xl lg:text-9xl">group.</p>
            @if(group()?.name){
              <p class="text-orange-600 text-6xl lg:text-9xl outline-2" [@textChange]> {{ getUppercaseName() }}</p>
            }
          }
          @else {
            <p></p>
          }
          <p class="text-6xl lg:text-9xl text-stone-200"> - </p>
        }
      </div>
      <div class="bg-orange-600 h-fit my-20 mx-20 border border-2 border-dashed border-gray-700 z-40">
        <app-group-stats 
          [group]="group()"
          [todoItemsList]="todoItemsList"
          (groupEdited)="onGroupEdit()">
        </app-group-stats>
      </div>
      <div class="bg-stone-200 h-1/6"></div>
      <div class="bg-stone-200 h-screen flex item-center justify-center relative z-40">
        <div class="w-3/4 grid grid-cols-3 gap-4">
          @for(todo of todoItemsList; track todo){
            <app-todo-item-card 
              [todoItem]="todo"
              (todoItemChanged)="getTodoItems()"
              [@textChange]>
            </app-todo-item-card>
          }
          @empty {
            <p class="text-3xl lg:text-4xl">Nothing for this set.</p>
          }
        </div>
        <div class="justify-center m-2">
          <a [routerLink]="'addTodoItem/' + group()?.id" [queryParams]=""  class="text-black hover:translate-y-2 text-6xl lg:text-9xl" >
            <mat-icon>add</mat-icon>
          </a>
        </div>
      </div>
    </div>
  `,
  styles: ``,
    animations: [
      trigger('textChange', [
        state('void', style({ opacity: 0 })),
        state('visible', style({ opacity: 1 })),
        transition('void => visible', [animate('0.3s ease-in')]),
      ]),
    ],
})
export class GroupContainerComponent implements OnInit {
  group = input<Group>();
  selectedSortOrder = input<SortOrder | undefined>();
  selectedCompletion = input<boolean>();
  groupChanged = output<number>();
  priority: Priority = Priority.Low;
  todoItemsList: TodoItem[] = [];
  private todoItemsService: TodoItemsService = inject(TodoItemsService);
  
  @ViewChild('groupWrapper', { static: true }) groupWrapper!: ElementRef;
  repeatedTexts = Array(7).fill(0);

  ngOnInit() {
    this.animateScroll();
    this.getTodoItems();
  }

  animateScroll() {
    const wrapperWidth = this.groupWrapper.nativeElement.offsetWidth;
    const textWidth = this.groupWrapper.nativeElement.scrollWidth;
    const clipWidth = wrapperWidth.offsetWidth;
    gsap.to(this.groupWrapper.nativeElement, {
      translateX: -(textWidth - wrapperWidth),
      duration: 75,
      ease: "none",
      repeat: -1,
      clip: `rect(auto, ${wrapperWidth}px, auto, 0px)`
    });
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['group'] || changes['selectedCompletion'] || changes['selectedSortOrder']) {
      this.animateScroll();
      this.getTodoItems();
    }
  }

  getTodoItems(){
    this.todoItemsService.getAllTodoItems(this.group()?.id, this.selectedCompletion(), this.selectedSortOrder()).subscribe({next: value => this.todoItemsList = value});
  }

  getUppercaseName(): string {
    return this.group()?.name?.replace(/[^a-zA-Z]/g, "").toUpperCase() || '';
  }

  onGroupEdit() {
    this.groupChanged.emit(this.group()?.id!);
  }
}